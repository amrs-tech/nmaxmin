# nmaxmin

A simple package to find the nth max and nth min in a list.

## Installation

```
pip install nmaxmin
```

